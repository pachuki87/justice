const express = require('express');
const serverless = require('serverless-http');
const cors = require('cors');
const { Pool } = require('pg');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
require('dotenv').config();

const app = express();

// Content Security Policy headers para protección XSS
const setCSPHeaders = (req, res, next) => {
  // Política CSP estricta para prevenir XSS
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'self'; " +
    "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; " +
    "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com https://fonts.googleapis.com; " +
    "font-src 'self' https://fonts.gstatic.com https://cdnjs.cloudflare.com; " +
    "img-src 'self' data: https:; " +
    "connect-src 'self' https://api.openai.com; " +
    "frame-src 'self'; " +
    "object-src 'none'; " +
    "base-uri 'self'; " +
    "form-action 'self'; " +
    "frame-ancestors 'none'; " +
    "upgrade-insecure-requests"
  );
  
  // Headers de seguridad adicionales
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');
  
  next();
};

app.use(cors());
app.use(express.json());
app.use(setCSPHeaders);

// Database connection with flexible SSL configuration
const createSecurePool = () => {
  const connectionString = process.env.DATABASE_URL;
  const isSSLDisabled = connectionString && connectionString.includes('sslmode=disable');
  
  // Base configuration
  const config = {
    connectionString: connectionString,
  };

  // Only apply SSL config if NOT disabled
  if (!isSSLDisabled) {
      config.ssl = {
        rejectUnauthorized: true, // Default to secure
        checkServerIdentity: () => undefined,
      };
      
      // Allow override from env vars
      if (process.env.DB_SSL_REJECT_UNAUTHORIZED === 'false') {
          config.ssl.rejectUnauthorized = false;
      }
  } else {
      console.log('⚠️ SSL desactivado explícitamente por configuración (sslmode=disable)');
      // Explicitly disable SSL for pg
      config.ssl = false; 
  }

  return config;
};

// Create pool with secure configuration
const pool = new Pool(createSecurePool());

// Enhanced error handling for SSL connection issues
pool.on('error', (err) => {
  console.error('Error inesperado en el pool de conexión:', err);
  
  // Specific SSL error handling
  if (err.code === 'UNABLE_TO_VERIFY_LEAF_SIGNATURE') {
    console.error('🚨 ERROR SSL: No se puede verificar el certificado del servidor');
    console.error('🚨 Posibles causas:');
    console.error('   - Certificado autofirmado sin CA configurada');
    console.error('   - Certificado expirado o inválido');
    console.error('   - Configuración de red incorrecta');
  } else if (err.code === 'DEPTH_ZERO_SELF_SIGNED_CERT') {
    console.error('🚨 ERROR SSL: Certificado autofirmado detectado');
    console.error('🚨 En producción, use certificados emitidos por una CA confiable');
  } else if (err.code === 'CERT_HAS_EXPIRED') {
    console.error('🚨 ERROR SSL: El certificado ha expirado');
    console.error('🚨 Renueve el certificado inmediatamente');
  }
});

// Connection validation function
const validateSSLConnection = async () => {
  try {
    const client = await pool.connect();
    const result = await client.query('SELECT NOW() as current_time, version() as postgres_version');
    client.release();
    
    console.log('✅ Conexión SSL validada exitosamente');
    console.log('📊 Base de datos conectada:', result.rows[0].postgres_version.split(' ')[0]);
    
    return { success: true, time: result.rows[0].current_time };
  } catch (err) {
    console.error('❌ Error validando conexión SSL:', err.message);
    
    // Enhanced error reporting for SSL issues
    if (err.message.includes('SSL')) {
      console.error('🔍 Detalles del error SSL:', {
        code: err.code,
        severity: err.severity,
        detail: err.detail,
        hint: err.hint
      });
      
      // Provide actionable guidance
      if (process.env.NODE_ENV === 'production') {
        console.error('🚨 ACCIÓN REQUERIDA: La conexión SSL falló en producción');
        console.error('🚨 Revise la configuración del certificado y la cadena de confianza');
      }
    }
    
    return { success: false, error: err.message, code: err.code };
  }
};

// Validate connection on startup
validateSSLConnection();

// Validación CRÍTICA de JWT_SECRET para seguridad
const validateJWTSecret = () => {
  const jwtSecret = process.env.JWT_SECRET;
  
  if (!jwtSecret) {
    console.error('🚨 VULNERABILIDAD CRÍTICA: JWT_SECRET no está configurado');
    console.error('🚨 Esto compromete toda la autenticación del sistema');
    console.error('🚨 ACCIÓN REQUERIDA: Configure JWT_SECRET en variables de entorno');
    console.error('🚨 Comando para generar secreto seguro: node -e "const crypto = require(\'crypto\'); console.log(crypto.randomBytes(64).toString(\'hex\'));"');
    process.exit(1); // Detener ejecución por seguridad
  }
  
  // Validar longitud mínima (mínimo 64 caracteres recomendado)
  if (jwtSecret.length < 64) {
    console.error('🚨 VULNERABILIDAD CRÍTICA: JWT_SECRET demasiado corto');
    console.error(`🚨 Longitud actual: ${jwtSecret.length} caracteres (mínimo 64 recomendado)`);
    console.error('🚨 Un secreto corto es vulnerable a ataques de fuerza bruta');
    console.error('🚨 ACCIÓN REQUERIDA: Use un JWT_SECRET de al menos 64 caracteres');
    process.exit(1); // Detener ejecución por seguridad
  }
  
  // Validar que no sea un valor por defecto o inseguro
  const insecurePatterns = [
    /secret/i,
    /default/i,
    /example/i,
    /test/i,
    /justice2-secret-key/,
    /GENERATE/,
    /temporal/i,
    /demo/i
  ];
  
  for (const pattern of insecurePatterns) {
    if (pattern.test(jwtSecret)) {
      console.error('🚨 VULNERABILIDAD CRÍTICA: JWT_SECRET contiene patrón inseguro');
      console.error('🚨 El secreto parece ser un valor por defecto o de ejemplo');
      console.error('🚨 ACCIÓN REQUERIDA: Genere un JWT_SECRET único y seguro');
      process.exit(1); // Detener ejecución por seguridad
    }
  }
  
  console.log('✅ JWT_SECRET validado correctamente');
  console.log(`🔐 Longitud del secreto: ${jwtSecret.length} caracteres`);
  return jwtSecret;
};

// Configuración JWT con validación estricta
const JWT_CONFIG = {
  secret: validateJWTSecret(), // Validación crítica al iniciar
  algorithm: 'HS256',
  expiresIn: '24h',
  issuer: 'justice2',
  audience: 'justice2-client'
};

// Helper to check auth token con validación completa
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({
      error: 'Token no proporcionado',
      code: 'TOKEN_MISSING'
    });
  }

  // Verificar formato del token
  const parts = token.split('.');
  if (parts.length !== 3) {
    return res.status(401).json({
      error: 'Token con formato inválido',
      code: 'TOKEN_INVALID_FORMAT'
    });
  }

  // Opciones de verificación JWT
  const verifyOptions = {
    algorithm: [JWT_CONFIG.algorithm],
    issuer: JWT_CONFIG.issuer,
    audience: JWT_CONFIG.audience,
    maxAge: '24h' // Tiempo máximo de vida del token
  };

  jwt.verify(token, JWT_CONFIG.secret, verifyOptions, (err, user) => {
    if (err) {
      console.error('Error verificando token:', err.message);
      
      // Mensajes específicos según el error
      let errorMessage = 'Token inválido';
      let errorCode = 'TOKEN_INVALID';
      
      if (err.name === 'TokenExpiredError') {
        errorMessage = 'Token expirado';
        errorCode = 'TOKEN_EXPIRED';
      } else if (err.name === 'JsonWebTokenError') {
        errorMessage = 'Token malformed';
        errorCode = 'TOKEN_MALFORMED';
      } else if (err.name === 'NotBeforeError') {
        errorMessage = 'Token no válido aún';
        errorCode = 'TOKEN_NOT_BEFORE';
      }
      
      return res.status(403).json({
        error: errorMessage,
        code: errorCode,
        details: process.env.NODE_ENV === 'development' ? err.message : undefined
      });
    }
    
    // Verificar claims adicionales
    if (!user.sub || !user.iat || !user.exp) {
      return res.status(403).json({
        error: 'Token con claims incompletos',
        code: 'TOKEN_INCOMPLETE_CLAIMS'
      });
    }
    
    req.user = user;
    req.token = token;
    next();
  });
};

const router = express.Router();

// --- AUTH ROUTES ---

// Login
router.post('/auth/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        // Special handling for public demo user
        if (email === 'public@example.com') {
             const user = {
                 id: '00000000-0000-0000-0000-000000000000',
                 email: 'public@example.com',
                 full_name: 'Public User',
                 role: 'admin'
             };
             
             // Crear token con claims estándar y seguridad mejorada
             const now = Math.floor(Date.now() / 1000);
             const tokenPayload = {
                 sub: user.id,           // Subject (ID del usuario)
                 iss: JWT_CONFIG.issuer, // Issuer (emisor)
                 aud: JWT_CONFIG.audience, // Audience (audiencia)
                 iat: now,              // Issued at (emitido en)
                 exp: now + (24 * 60 * 60), // Expires in (expira en 24h)
                 nbf: now,              // Not before (no válido antes de ahora)
                 jti: require('uuid').v4(), // JWT ID (identificador único)
                 email: user.email,
                 role: user.role
             };
             
             const token = jwt.sign(tokenPayload, JWT_CONFIG.secret, {
                 algorithm: JWT_CONFIG.algorithm,
                 expiresIn: JWT_CONFIG.expiresIn
             });
             
             return res.json({ token, user });
        }

        const result = await pool.query('SELECT * FROM profiles WHERE email = $1', [email]);
        
        if (result.rows.length === 0) {
             return res.status(401).json({ error: 'Invalid credentials. Try public@example.com' });
        }

        const user = result.rows[0];
        
        // Crear token con claims estándar y seguridad mejorada
        const now = Math.floor(Date.now() / 1000);
        const tokenPayload = {
            sub: user.id,           // Subject (ID del usuario)
            iss: JWT_CONFIG.issuer, // Issuer (emisor)
            aud: JWT_CONFIG.audience, // Audience (audiencia)
            iat: now,              // Issued at (emitido en)
            exp: now + (24 * 60 * 60), // Expires in (expira en 24h)
            nbf: now,              // Not before (no válido antes de ahora)
            jti: require('uuid').v4(), // JWT ID (identificador único)
            email: user.email,
            role: user.role || 'user'
        };
        
        const token = jwt.sign(tokenPayload, JWT_CONFIG.secret, {
            algorithm: JWT_CONFIG.algorithm,
            expiresIn: JWT_CONFIG.expiresIn
        });
        
        res.json({ token, user });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// Register
router.post('/auth/register', async (req, res) => {
    const { email, password, name } = req.body;
    try {
        // Special handling to redirect to demo user
        if (email === 'public@example.com') {
             const user = {
                 id: '00000000-0000-0000-0000-000000000000',
                 email: 'public@example.com',
                 full_name: 'Public User'
             };
             
             // Crear token con claims estándar y seguridad mejorada
             const now = Math.floor(Date.now() / 1000);
             const tokenPayload = {
                 sub: user.id,           // Subject (ID del usuario)
                 iss: JWT_CONFIG.issuer, // Issuer (emisor)
                 aud: JWT_CONFIG.audience, // Audience (audiencia)
                 iat: now,              // Issued at (emitido en)
                 exp: now + (24 * 60 * 60), // Expires in (expira en 24h)
                 nbf: now,              // Not before (no válido antes de ahora)
                 jti: require('uuid').v4(), // JWT ID (identificador único)
                 email: user.email,
                 role: 'user'
             };
             
             const token = jwt.sign(tokenPayload, JWT_CONFIG.secret, {
                 algorithm: JWT_CONFIG.algorithm,
                 expiresIn: JWT_CONFIG.expiresIn
             });
             
             return res.json({ token, user });
        }

        const id = uuidv4();
        await pool.query(
            'INSERT INTO profiles (id, email, full_name, created_at, updated_at) VALUES ($1, $2, $3, NOW(), NOW())',
            [id, email, name]
        );
        
        // Crear token con claims estándar y seguridad mejorada
        const now = Math.floor(Date.now() / 1000);
        const tokenPayload = {
            sub: id,                // Subject (ID del usuario)
            iss: JWT_CONFIG.issuer, // Issuer (emisor)
            aud: JWT_CONFIG.audience, // Audience (audiencia)
            iat: now,              // Issued at (emitido en)
            exp: now + (24 * 60 * 60), // Expires in (expira en 24h)
            nbf: now,              // Not before (no válido antes de ahora)
            jti: require('uuid').v4(), // JWT ID (identificador único)
            email: email,
            role: 'user'
        };
        
        const token = jwt.sign(tokenPayload, JWT_CONFIG.secret, {
            algorithm: JWT_CONFIG.algorithm,
            expiresIn: JWT_CONFIG.expiresIn
        });
        
        res.json({ token, user: { id, email, full_name: name } });
    } catch (err) {
        console.error(err);
        if (err.code === '23503') { // Foreign key violation
            res.status(400).json({ error: 'Registration is restricted. Please login with public@example.com' });
        } else {
            res.status(500).json({ error: err.message });
        }
    }
});

// Profile
router.get('/auth/profile', authenticateToken, async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM profiles WHERE id = $1', [req.user.id]);
        if (result.rows.length === 0) return res.sendStatus(404);
        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// --- CASES ROUTES ---

router.get('/cases', authenticateToken, async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM cases WHERE user_id = $1 ORDER BY created_at DESC', [req.user.id]);
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.post('/cases', authenticateToken, async (req, res) => {
    const { title, description, client_id, status, priority } = req.body;
    const id = uuidv4();
    try {
        const result = await pool.query(
            'INSERT INTO cases (id, user_id, client_id, title, description, status, priority, created_at, updated_at) VALUES ($1, $2, $3, $4, $5, $6, $7, NOW(), NOW()) RETURNING *',
            [id, req.user.id, client_id, title, description, status || 'open', priority || 'medium']
        );
        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.get('/cases/:id', authenticateToken, async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM cases WHERE id = $1 AND user_id = $2', [req.params.id, req.user.id]);
        if (result.rows.length === 0) return res.sendStatus(404);
        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// --- CLIENTS ROUTES ---

router.get('/clients', authenticateToken, async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM clients WHERE user_id = $1 ORDER BY name', [req.user.id]);
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.post('/clients', authenticateToken, async (req, res) => {
    const { name, email, phone, address } = req.body;
    const id = uuidv4();
    try {
        const result = await pool.query(
            'INSERT INTO clients (id, user_id, name, email, phone, address, created_at, updated_at) VALUES ($1, $2, $3, $4, $5, $6, NOW(), NOW()) RETURNING *',
            [id, req.user.id, name, email, phone, address]
        );
        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// --- ANALYTICS ROUTES ---

router.get('/analytics/dashboard', authenticateToken, async (req, res) => {
    try {
        // Mock dashboard data for now
        res.json({
            cases: { total: 12, active: 5, pending: 3, closed: 4 },
            documents: { total: 45, processed: 40, pending: 5 },
            performance: { efficiency: 85, satisfaction: 92 },
            recent_activity: []
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// --- DOCUMENTS ROUTES ---

router.get('/documents', authenticateToken, async (req, res) => {
    try {
        // Mock documents list for now
        res.json([]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// --- AI ROUTES (Mock for now) ---

router.post('/ai/chat', authenticateToken, async (req, res) => {
    const { message, context } = req.body;
    // In future: Call OpenAI or similar here.
    // For now, return a simulated response.
    res.json({
        response: `Entendido. He recibido tu consulta sobre "${message}". Como asistente legal de Justice 2, puedo ayudarte a analizar este caso basándome en la legislación vigente. ¿Te gustaría que busque precedentes?`,
        suggestedActions: ['Buscar jurisprudencia', 'Redactar demanda', 'Calcular indemnización']
    });
});

// --- HEALTH CHECK ---
router.get('/health', async (req, res) => {
  try {
    // Use enhanced SSL validation
    const validation = await validateSSLConnection();
    
    if (validation.success) {
      res.json({
        status: 'ok',
        time: validation.time,
        connection: 'success',
        ssl: 'validated',
        security: 'enforced'
      });
    } else {
      // Provide detailed SSL error information
      res.status(503).json({
        status: 'error',
        message: validation.error,
        code: validation.code,
        connection: 'failed',
        ssl: 'validation_failed',
        security: 'compromised'
      });
    }
  } catch (err) {
    console.error('Database connection error:', err);
    res.status(500).json({
      status: 'error',
      message: err.message,
      connection: 'failed',
      ssl: 'unknown',
      security: 'error'
    });
  }
});

// Mount router
app.use('/api', router);
app.use('/', router); // Fallback for direct function access

module.exports.handler = serverless(app);
